import os
import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from core_v13 import QIHO_GodKiller

# Load dataset
df = pd.read_csv("content/drive/MyDrive/QIHO/credit_data.csv")

# Drop ID column and split features/target
df.drop("ID", axis=1, inplace=True)
X = df.drop("default.payment.next.month", axis=1).values
y = df["default.payment.next.month"].values

# Train/test split
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# Convert to torch tensors
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train.reshape(-1, 1), dtype=torch.float32)
X_val = torch.tensor(X_val, dtype=torch.float32)
y_val = torch.tensor(y_val.reshape(-1, 1), dtype=torch.float32)

# Use GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Define the MLP model
class CreditMLP(nn.Module):
    def __init__(self, input_dim, hidden1=64, hidden2=32, dropout=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden1),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden1, hidden2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden2, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.net(x)

# Define the objective function for QIHO++
def evaluate_model(hyperparams):
    lr, hidden1, hidden2, dropout = hyperparams
    hidden1 = int(hidden1)
    hidden2 = int(hidden2)
    dropout = float(dropout)

    model = CreditMLP(X_train.shape[1], hidden1, hidden2, dropout).to(device)
    criterion = nn.BCELoss()
    optimizer = optim.Adam(model.parameters(), lr=float(lr))

    model.train()
    for epoch in range(10):
        optimizer.zero_grad()
        outputs = model(X_train.to(device))
        loss = criterion(outputs, y_train.to(device))
        loss.backward()
        optimizer.step()

    model.eval()
    with torch.no_grad():
        preds = model(X_val.to(device)).cpu().numpy()
        preds = (preds > 0.5).astype(int)
        acc = accuracy_score(y_val.numpy(), preds)

    # Return negative accuracy as cost (since QIHO minimizes)
    return -acc

# Define hyperparameter bounds
search_space = [
    (1e-4, 1e-2),        # Learning rate
    (32, 256),           # Hidden layer 1 size
    (16, 128),           # Hidden layer 2 size
    (0.1, 0.5)           # Dropout
]

# Run QIHO_GodKiller optimizer
optimizer = QIHO_GodKiller(
    obj_func=evaluate_model,
    bounds=search_space,
    n_dims=len(search_space),
    max_evals=30,
    log_callback=lambda evals, best_cost: print(f"[{evals}] Acc: {-best_cost:.4f}")
)

best_result = optimizer.run()
print("\nBest hyperparameters found:")
print("Learning rate :", best_result['position'][0])
print("Hidden1 units :", int(best_result['position'][1]))
print("Hidden2 units :", int(best_result['position'][2]))
print("Dropout       :", best_result['position'][3])
print("Validation Accuracy :", -best_result['cost'])
