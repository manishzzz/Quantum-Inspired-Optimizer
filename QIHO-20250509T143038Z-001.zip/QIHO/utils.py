# File: utils.py

import matplotlib.pyplot as plt

def plot_convergence(history, title="Convergence Plot", ylabel="Loss"):
    plt.figure(figsize=(8, 5))
    plt.plot(history, marker='o', color='dodgerblue')
    plt.title(title)
    plt.xlabel("Iteration")
    plt.ylabel(ylabel)
    plt.grid(True)
    plt.tight_layout()
    plt.show()
