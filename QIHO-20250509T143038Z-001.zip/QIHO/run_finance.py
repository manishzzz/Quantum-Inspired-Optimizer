# File: run_finance.py

from core_v13 import QIHO_GodKiller
from finance_credit import objective_function
from utils import plot_convergence

import numpy as np

log_callback = lambda i, loss: print(f"[{i}] Validation Loss (1 - Acc): {loss:.6f}")

optimizer = QIHO_GodKiller(
    dim=3,
    bounds=[[-5, -2], [0.0, 0.5], [16, 256]],
    max_iter=10,
    n_universes=16,
    objective_function=objective_function,
    log_callback=log_callback
)


best_params, best_loss, history = optimizer.optimize()
print("\nBest Params (log10 lr, dropout, hidden):", best_params)
print("Best Validation Accuracy:", 1.0 - best_loss)

plot_convergence(history, title="QIHO-GodKiller Convergence (1 - Accuracy)")
