# core_v13.py (GodKiller++ Updated)

import numpy as np

class QIHO_GodKiller:
    def __init__(
        self,
        dim,
        bounds,
        max_iter=1000,
        n_universes=40,
        objective_function=None,
        log_callback=None
    ):
        self.dim = dim
        self.bounds = np.array(bounds)
        self.max_iter = max_iter
        self.n_universes = n_universes
        self.obj_func = objective_function or self._default_obj_func
        self.log_callback = log_callback
        self.lb, self.ub = self.bounds[:, 0], self.bounds[:, 1]

        # Initialize universes (population)
        self.positions = np.random.uniform(self.lb, self.ub, (n_universes, dim))
        self.best_score = np.inf
        self.best_pos = None
        self.convergence = []

    def _default_obj_func(self, x):
        return np.sum(np.square(x))  # fallback if no objective provided

    def _evaluate(self):
        fitness = np.array([self.obj_func(pos) for pos in self.positions])
        best_idx = np.argmin(fitness)
        if fitness[best_idx] < self.best_score:
            self.best_score = fitness[best_idx]
            self.best_pos = self.positions[best_idx].copy()
        return fitness

    def _quantum_tunneling(self, iter_idx):
        q_strength = 0.005 + (np.log1p(iter_idx) / self.max_iter) * 0.5
        return np.random.normal(0, q_strength, (self.n_universes, self.dim))

    def _fourier_turbulence(self, iter_idx):
        phase_shift = np.pi * np.random.rand(self.n_universes, self.dim)
        freqs = np.linspace(0.5, 2.5, self.dim)
        t = iter_idx / self.max_iter
        return 0.1 * np.sin(2 * np.pi * freqs * t + phase_shift)

    def _phase_synced_mutation(self, iter_idx):
        amp = 0.2 * np.exp(-iter_idx / self.max_iter)
        freq = 5 + 10 * np.random.rand(self.n_universes, self.dim)
        phase = np.random.rand(self.n_universes, self.dim) * 2 * np.pi
        t = iter_idx / self.max_iter
        return amp * np.cos(2 * np.pi * freq * t + phase)

    def _resonance_jump(self, iter_idx):
        if iter_idx % 200 == 0 and iter_idx > 0:
            return np.random.uniform(-1, 1, (self.n_universes, self.dim)) * 0.2
        return 0

    def optimize(self):
        for iter_idx in range(self.max_iter):
            fitness = self._evaluate()
            inertia = np.random.uniform(0.5, 1.0, (self.n_universes, self.dim))

            # Strategy Fusion
            quantum = self._quantum_tunneling(iter_idx)
            fourier = self._fourier_turbulence(iter_idx)
            phase_mut = self._phase_synced_mutation(iter_idx)
            resonance = self._resonance_jump(iter_idx)

            delta = (
                0.6 * inertia * (self.best_pos - self.positions) +
                0.2 * quantum +
                0.1 * fourier +
                0.1 * phase_mut +
                resonance
            )

            # Update positions
            self.positions += delta
            self.positions = np.clip(self.positions, self.lb, self.ub)

            # Logging
            self.convergence.append(self.best_score)
            if self.log_callback:
                self.log_callback(iter_idx, self.best_score)

        return self.best_pos, self.best_score, self.convergence
