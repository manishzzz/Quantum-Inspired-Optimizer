import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader, random_split
import numpy as np
import matplotlib.pyplot as plt
import os
from core_v13 import QIHO_GodKiller  # Ensure this file is present
import sys

# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device, flush=True)

# Load dataset
print("Loading dataset...", flush=True)
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
])

data_dir = "/content/drive/MyDrive/QIHO_Plus_Plus/datasets/chest_xray/train"
dataset = ImageFolder(root=data_dir, transform=transform)
print(f"Total images found: {len(dataset)}", flush=True)

# Split dataset
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
print(f"Train size: {train_size}, Val size: {val_size}", flush=True)

# Initial loaders (will be updated during optimization)
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=16)

# Simple CNN model
class SimpleCNN(nn.Module):
    def __init__(self, dropout_rate):
        super(SimpleCNN, self).__init__()
        self.model = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(32 * 32 * 32, 128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 2)
        )

    def forward(self, x):
        return self.model(x)

# Objective function
def objective_function(params):
    print(f"Evaluating params: {params}", flush=True)

    lr = 10 ** params[0]
    dropout = float(params[1])
    batch_size = int(params[2])

    model = SimpleCNN(dropout).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    # Update loaders with new batch size
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size)

    model.train()
    for epoch in range(1):  # One epoch for quick feedback
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()

    # Validation
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for inputs, targets in val_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs.data, 1)
            total += targets.size(0)
            correct += (predicted == targets).sum().item()

    acc = correct / total
    print(f"Validation Accuracy: {acc:.4f}", flush=True)
    return 1 - acc  # Minimize 1 - acc

# Logging and convergence tracking
convergence_curve = []

def log_callback(iter_idx, best_score):
    print(f"[{iter_idx}] Best validation loss (1 - Acc): {best_score:.6f}", flush=True)
    convergence_curve.append(best_score)

# Main script
if __name__ == "__main__":
    print("Starting optimization script...", flush=True)

    bounds = [
        [-5, -2],     # log10(learning rate)
        [0.1, 0.7],   # dropout
        [8, 64]       # batch size
    ]

    optimizer = QIHO_GodKiller(
        obj_func=objective_function,
        dim=3,
        bounds=bounds,
        max_iter=8,           # Recommended for deep tasks
        n_universes=3,        # Reasonable population
        log_callback=log_callback
    )

    print("Launching QIHO optimization...", flush=True)

    best_params, best_loss, _ = optimizer.optimize()
    best_acc = 1 - best_loss

    print("\nBest Params (log10 lr, dropout, batch size):", best_params, flush=True)
    print("Best Validation Accuracy:", best_acc, flush=True)

    # Plot convergence curve
    plt.figure(figsize=(8, 5))
    plt.plot(convergence_curve, marker='o', linewidth=2, color='blue')
    plt.title("QIHO-GodKiller Convergence (1 - Accuracy)")
    plt.xlabel("Iteration")
    plt.ylabel("Validation Loss (1 - Acc)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("convergence_curve.png")
    plt.show()
